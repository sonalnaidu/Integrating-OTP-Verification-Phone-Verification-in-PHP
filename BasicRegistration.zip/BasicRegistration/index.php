<html >
   <head>
      <meta charset="UTF-8">
   </head>
   <body>
      <h2>Register Here </h2>
      <form action="action_otp.php" method="post">
         Name:<br>
         <input type="text" name="name" value="">
         <br>
         Email:<br>
         <input type="text" name="email" value="">
         <br>
         Phone Number:<br>
         <input type="text" name="phone" value="">
         <br><br>
         <input type="submit" value="Submit">
      </form>
   </body>
</html>